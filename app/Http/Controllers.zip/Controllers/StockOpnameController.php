<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\StockOpnameHeader;
use App\StockOpnameDetail;
use App\Item;
use Carbon\Carbon;
use App\Helpers\InventoryHelper;
use Excel;

class StockOpnameController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth');

        // === SECURITY LAYER: PERFEKSIONIS ===
        // Memblokir User Dept (USER) agar tidak bisa akses Controller Admin ini.
        // Jika nekat akses URL manual, tendang balik ke halaman Request.
        $this->middleware(function ($request, $next) {
            $user = \Auth::user();
            if ($user && $user->role === 'USER') {
                return redirect()->route('requests.index')->with('error', 'Akses Ditolak! Anda tidak memiliki izin ke halaman tersebut.');
            }
            return $next($request);
        });
    }
    
    // --- LIST ---
    public function index(Request $request)
    {
        $q       = trim($request->get('q', ''));
        
        // --- UPDATE: DEFAULT DATE LOGIC (1st Month to Today) ---
        // Jika request 'date_from' kosong, set ke tanggal 1 bulan ini.
        $dfrom   = $request->has('date_from') ? $request->get('date_from') : date('Y-m-01');
        // Jika request 'date_to' kosong, set ke hari ini.
        $dto     = $request->has('date_to') ? $request->get('date_to') : date('Y-m-d');
        
        $perPage = (int) $request->get('per_page', 10);
        if ($perPage < 1) {
            $perPage = 10;
        }

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $query = StockOpnameHeader::query();

        // Scope User
        if (!is_null($allowedItemIds)) {
            $query->whereHas('details', function ($d) use ($allowedItemIds) {
                $d->whereIn('item_id', $allowedItemIds);
            })->withCount(['details' => function ($d) use ($allowedItemIds) {
                $d->whereIn('item_id', $allowedItemIds);
            }]);
        } else {
            $query->withCount('details');
        }

        if ($q !== '') {
            $query->where(function ($w) use ($q) {
                $w->where('notes', 'ilike', '%' . $q . '%')
                    ->orWhere(DB::raw("CAST(id AS TEXT)"), 'like', '%' . $q . '%');
            });
        }
        
        // Filter Tanggal yang sudah pasti terisi
        if ($dfrom !== '') {
            $query->where('opname_date', '>=', $dfrom);
        }
        if ($dto !== '') {
            $query->where('opname_date', '<=', $dto);
        }

        $query->orderBy('opname_date', 'desc')->orderBy('id', 'desc');
        $opnameHeaders = $query->paginate($perPage)->appends($request->query());

        return view('stock_opnames.index', compact('opnameHeaders', 'q', 'dfrom', 'dto', 'perPage'));
    }

    // --- CREATE FORM ---
    public function create()
    {
        $categoriesQuery = DB::table('categories')->orderBy('name', 'asc');

        $user = Auth::user();
        if ($user) {
            $scope = $user->inventory_scope;
            if ($scope !== 'ALL' && $scope !== null && $scope !== '') {
                $codes = method_exists($user, 'categoryCodesForScope')
                    ? $user->categoryCodesForScope()
                    : [];

                if (!empty($codes)) {
                    $categoriesQuery->whereIn('code', $codes);
                }
            }
        }

        $categories = $categoriesQuery->get();
        return view('stock_opnames.create', compact('categories'));
    }

    // --- API: LOAD ITEMS (SNAPSHOT DATA) ---
    public function getItemsByCategory(Request $request)
    {
        $catId = $request->get('category_id');
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $query = DB::table('items')
            ->select('id', 'code', 'name', 'unit', 'current_stock', 'location')
            ->where('current_status', 'ACTIVE');

        if (!is_null($allowedItemIds)) {
            $query->whereIn('id', $allowedItemIds);
        }

        if ($catId && $catId !== 'all') {
            $query->where('category_id', (int) $catId);
        }

        $items = $query->orderBy('location', 'asc')->orderBy('code', 'asc')->get();

        return response()->json($items);
    }

    // --- STORE ---
    public function store(Request $request)
    {
        $this->validate($request, [
            'opname_date' => 'required|date',
        ]);

        DB::beginTransaction();
        try {
            $header = StockOpnameHeader::create([
                'opname_date' => Carbon::parse($request->get('opname_date')),
                'notes'       => $request->get('notes'),
                'status'      => 'DRAFT'
            ]);

            $itemsData = [];
            if ($request->has('items_json')) {
                $itemsData = json_decode($request->get('items_json'), true);
            }

            $detailsToInsert = [];
            $now = Carbon::now();

            foreach ($itemsData as $r) {
                if (!isset($r['item_id'])) {
                    continue;
                }

                $system   = isset($r['system']) ? (int) $r['system'] : 0;
                $physical = isset($r['physical']) ? (int) $r['physical'] : 0;
                $diff     = $physical - $system;

                $detailsToInsert[] = [
                    'opname_header_id'  => $header->id,
                    'item_id'           => (int) $r['item_id'],
                    'system_quantity'   => $system,
                    'physical_quantity' => $physical,
                    'difference'        => $diff,
                    'notes'             => isset($r['notes']) ? $r['notes'] : null,
                    'created_at'        => $now,
                    'updated_at'        => $now
                ];
            }

            foreach (array_chunk($detailsToInsert, 500) as $chunk) {
                StockOpnameDetail::insert($chunk);
            }

            DB::commit();
            return redirect()->route('stock-opnames.show', $header->id)
                ->with('success', 'Draft SO berhasil disimpan. Silakan review.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Gagal menyimpan: ' . $e->getMessage());
        }
    }

    // --- SHOW ---
    public function show($id)
    {
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $opname = StockOpnameHeader::with(['details.item'])->findOrFail($id);

        if (!is_null($allowedItemIds)) {
            $filtered = $opname->details->filter(function ($d) use ($allowedItemIds) {
                return in_array($d->item_id, $allowedItemIds);
            })->values();
            $opname->setRelation('details', $filtered);
        }

        return view('stock_opnames.show', compact('opname'));
    }

    // --- EDIT ---
    public function edit($id)
    {
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $opname = StockOpnameHeader::with(['details.item'])->findOrFail($id);

        if ($opname->status === 'PROCESSED') {
            return redirect()->route('stock-opnames.show', $id)
                ->with('error', 'SO yang sudah diproses tidak bisa diedit.');
        }

        if (!is_null($allowedItemIds)) {
            $filtered = $opname->details->filter(function ($d) use ($allowedItemIds) {
                return in_array($d->item_id, $allowedItemIds);
            })->values();
            $opname->setRelation('details', $filtered);
        }

        $categoriesQuery = DB::table('categories')->orderBy('name', 'asc');

        $user = Auth::user();
        if ($user) {
            $scope = $user->inventory_scope;
            if ($scope !== 'ALL' && $scope !== null && $scope !== '') {
                $codes = method_exists($user, 'categoryCodesForScope')
                    ? $user->categoryCodesForScope()
                    : [];

                if (!empty($codes)) {
                    $categoriesQuery->whereIn('code', $codes);
                }
            }
        }
        $categories = $categoriesQuery->get();

        $detailsJson = $opname->details->map(function ($d) {
            return [
                'item_id'  => $d->item_id,
                'code'     => $d->item ? $d->item->code : 'N/A',
                'name'     => $d->item ? $d->item->name : '-',
                'location' => $d->item ? $d->item->location : '-',
                'unit'     => $d->item ? $d->item->unit : '-',
                'system'   => (int) $d->system_quantity,
                'physical' => (int) $d->physical_quantity,
                'notes'    => $d->notes
            ];
        });

        return view('stock_opnames.edit', compact('opname', 'detailsJson', 'categories'));
    }

    // --- UPDATE ---
    public function update(Request $request, $id)
    {
        $opname = StockOpnameHeader::findOrFail($id);
        if ($opname->status === 'PROCESSED') {
            return back()->with('error', 'Sudah diproses.');
        }

        DB::beginTransaction();
        try {
            $opname->opname_date = Carbon::parse($request->get('opname_date'));
            $opname->notes       = $request->get('notes');
            $opname->save();

            StockOpnameDetail::where('opname_header_id', $id)->delete();

            $itemsData = [];
            if ($request->has('items_json')) {
                $itemsData = json_decode($request->get('items_json'), true);
            }

            $detailsToInsert = [];
            $now = Carbon::now();

            foreach ($itemsData as $r) {
                if (!isset($r['item_id'])) {
                    continue;
                }
                $system   = (int) $r['system'];
                $physical = (int) $r['physical'];
                $diff     = $physical - $system;

                $detailsToInsert[] = [
                    'opname_header_id'  => $opname->id,
                    'item_id'           => (int) $r['item_id'],
                    'system_quantity'   => $system,
                    'physical_quantity' => $physical,
                    'difference'        => $diff,
                    'notes'             => isset($r['notes']) ? $r['notes'] : null,
                    'created_at'        => $now,
                    'updated_at'        => $now
                ];
            }

            foreach (array_chunk($detailsToInsert, 500) as $chunk) {
                StockOpnameDetail::insert($chunk);
            }

            DB::commit();
            return redirect()->route('stock-opnames.show', $opname->id)->with('success', 'Update berhasil.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', $e->getMessage());
        }
    }

    // --- PROCESS (Finalize & Adjust Stok) ---
    public function process($id)
    {
        $opname = StockOpnameHeader::with('details')->findOrFail($id);
        if ($opname->status === 'PROCESSED') {
            return back()->with('error', 'Sudah diproses.');
        }

        DB::beginTransaction();
        try {
            foreach ($opname->details as $d) {
                if ($d->difference != 0) {
                    InventoryHelper::recordMovement(
                        $d->item_id,
                        $opname->opname_date,
                        'OPNAME',
                        $opname->id,
                        'SO-' . $opname->id,
                        $d->difference
                    );
                }
            }
            $opname->status = 'PROCESSED';
            $opname->save();
            DB::commit();
            return redirect()->route('stock-opnames.show', $id)->with('success', 'Stok berhasil disesuaikan.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal proses: ' . $e->getMessage());
        }
    }

    // --- EXPORT EXCEL ---
    public function exportExcel($id)
    {
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $opname = StockOpnameHeader::with(['details.item'])->findOrFail($id);
        $data   = $opname->details;

        if (!is_null($allowedItemIds)) {
            $data = $data->filter(function ($d) use ($allowedItemIds) {
                return in_array($d->item_id, $allowedItemIds);
            })->values();
        }

        $filename = 'Stock_Opname_' . $opname->opname_date->format('Ymd') . '_' . $opname->id;

        return Excel::create($filename, function ($excel) use ($data, $opname) {
            $excel->sheet('SO Result', function ($sheet) use ($data, $opname) {
                $sheet->mergeCells('A1:G1');
                $sheet->row(1, ['LAPORAN STOCK OPNAME']);
                $sheet->row(1, function ($row) {
                    $row->setFontWeight('bold')->setFontSize(14)->setAlignment('center');
                });

                $sheet->mergeCells('A2:G2');
                $sheet->row(2, ['Tanggal: ' . $opname->opname_date->format('d M Y') . ' | Ref: #' . $opname->id]);
                $sheet->row(2, function ($row) {
                    $row->setAlignment('center');
                });

                $sheet->row(4, ['NO', 'KODE', 'NAMA BARANG', 'SAT', 'STOCK CARD (SISTEM)', 'STOCK OPNAME (FISIK)', 'SELISIH UNIT']);
                $sheet->row(4, function ($row) {
                    $row->setBackground('#E0E0E0');
                    $row->setFontWeight('bold');
                    $row->setAlignment('center');
                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $rowNum = 5;
                $no = 1;
                foreach ($data as $d) {
                    $item = $d->item;
                    $sheet->row($rowNum, [
                        $no,
                        $item ? $item->code : '-',
                        $item ? $item->name : 'Item Terhapus',
                        $item ? $item->unit : '-',
                        (int) $d->system_quantity,
                        (int) $d->physical_quantity,
                        (int) $d->difference
                    ]);

                    $sheet->row($rowNum, function ($row) {
                        $row->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    if ($d->difference < 0) {
                        $sheet->cell('G' . $rowNum, function ($cell) {
                            $cell->setFontColor('#FF0000')->setFontWeight('bold');
                        });
                    } elseif ($d->difference > 0) {
                        $sheet->cell('G' . $rowNum, function ($cell) {
                            $cell->setFontColor('#16A34A')->setFontWeight('bold');
                        });
                    }
                    $rowNum++;
                    $no++;
                }
                $sheet->setAutoSize(true);
            });
        })->download('xlsx');
    }

    // --- ROLLBACK ---
    public function rollback($id)
    {
        $opname = StockOpnameHeader::with('details')->findOrFail($id);

        if ($opname->status !== 'PROCESSED') {
            return redirect()->back()->with('error', 'Hanya SO yang sudah diproses yang bisa dibatalkan.');
        }

        DB::beginTransaction();
        try {
            InventoryHelper::deleteMovement('OPNAME', $opname->id);

            $opname->status = 'DRAFT';
            $opname->save();

            DB::commit();
            return redirect()->route('stock-opnames.show', $id)
                ->with('success', 'Proses dibatalkan. Stok telah dikembalikan ke awal. Silakan edit jika ada kesalahan.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal rollback: ' . $e->getMessage());
        }
    }

    // --- DESTROY (DELETE) ---
    // Update: Fitur Delete yang aman & bersih
    public function destroy($id)
    {
        $opname = StockOpnameHeader::with('details')->findOrFail($id);
        
        DB::beginTransaction();
        try {
            // Jika sudah processed, hapus juga movement stoknya agar balance kembali
            if ($opname->status === 'PROCESSED') {
                InventoryHelper::deleteMovement('OPNAME', $opname->id);
            }

            // Hapus detail terlebih dahulu
            StockOpnameDetail::where('opname_header_id', $id)->delete();
            
            // Hapus header
            $opname->delete();

            DB::commit();
            return redirect()->route('stock-opnames.index')->with('success', 'Data Stock Opname #' . $id . ' berhasil dihapus.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal menghapus data: ' . $e->getMessage());
        }
    }

    /**
     * Helper scope item (dipakai di beberapa method).
     */
    protected function getAllowedItemIdsForCurrentUser()
    {
        $user = Auth::user();
        if (!$user) {
            return null;
        }

        $scope = $user->inventory_scope;

        if ($scope === 'ALL' || $scope === null || $scope === '') {
            return null;
        }

        $categoryCodes = [];
        if (method_exists($user, 'categoryCodesForScope')) {
            $categoryCodes = $user->categoryCodesForScope();
        }

        if (empty($categoryCodes)) {
            return null;
        }

        return Item::whereHas('category', function ($q) use ($categoryCodes) {
            $q->whereIn('code', $categoryCodes);
        })->pluck('id')->toArray();
    }
}