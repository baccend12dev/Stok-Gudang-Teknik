<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BonHeader;
use App\BonDetail;
use App\Item;
use App\Department;
use App\DepartmentItemQuota;
use Carbon\Carbon;
use DB;
use App\Helpers\InventoryHelper; // <-- Panggil Helper

class BonController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth');

        // === SECURITY LAYER: PERFEKSIONIS ===
        // Memblokir User Dept (USER) agar tidak bisa akses Controller Admin ini.
        // Jika nekat akses URL manual, tendang balik ke halaman Request.
        $this->middleware(function ($request, $next) {
            $user = \Auth::user();
            if ($user && $user->role === 'USER') {
                return redirect()->route('requests.index')->with('error', 'Akses Ditolak! Anda tidak memiliki izin ke halaman tersebut.');
            }
            return $next($request);
        });
    }
    
    /**
     * Daftar departemen INDUK yang aktif.
     */
    protected function getActiveRootDepartments()
    {
        $q = Department::query();

        // filter aktif kalau kolomnya ada
        if (\Schema::hasColumn('departments', 'is_active')) {
            $q->where('is_active', 1);
        }

        // ambil yang induk kalau punya parent_id
        if (\Schema::hasColumn('departments', 'parent_id')) {
            $q->whereNull('parent_id');
        }

        return $q->orderBy('name', 'asc')->get();
    }

    /**
     * API AJAX: Mengambil daftar divisi berdasarkan ID Departemen
     * Route: /api/divisions (Pastikan sudah didaftarkan di web.php)
     */
    public function getDivisionsByDept(Request $request)
    {
        $deptId = $request->get('department_id');
        
        if (!$deptId) {
            return response()->json([]);
        }

        // Ambil dari tabel divisions yang sudah di-seed
        $divisions = DB::table('divisions')
            ->where('department_id', $deptId)
            ->orderBy('name', 'asc')
            ->select('id', 'name')
            ->get();

        return response()->json($divisions);
    }

    /**
     * Ringkasan kuota 1 dept + item
     */
    protected function getDeptQuotaInfo($departmentId, $itemId, $excludeBonId = null)
    {
        $total = DepartmentItemQuota::where('department_id', $departmentId)
            ->where('item_id', $itemId)
            ->sum('quota_quantity');

        if (!$total) {
            return [
                'total'     => 0,
                'used'      => 0,
                'remaining' => 0,
            ];
        }

        $usedQuery = BonDetail::where('item_id', $itemId)
            ->whereHas('bonHeader', function ($q) use ($departmentId, $excludeBonId) {
                $q->where('department_id', $departmentId)
                  ->whereIn('status', ['APPROVED', 'ISSUED']);

                if (!is_null($excludeBonId)) {
                    $q->where('id', '!=', $excludeBonId);
                }
            });

        $used = (int) $usedQuery->sum('approved_quantity');

        $total  = (int) $total;
        $remain = $total - $used;
        if ($remain < 0) {
            $remain = 0;
        }

        return [
            'total'     => $total,
            'used'      => $used,
            'remaining' => $remain,
        ];
    }

    // =====================================================================
    // REPORT - BON PER ITEM
    // =====================================================================
    public function reportPerItem(Request $request)
    {
        // --- UPDATE: DEFAULT DATE LOGIC (1st Month to Today) ---
        $from    = $request->has('from') ? $request->get('from') : date('Y-m-01');
        $to      = $request->has('to') ? $request->get('to') : date('Y-m-d');
        
        $itemId  = $request->get('item_id');
        $perPage = (int) $request->get('perPage', 25);

        if ($perPage <= 0) {
            $perPage = 25;
        }

        $selectedDepartments = $request->get('departments', []);
        if (!is_array($selectedDepartments)) {
            if ($selectedDepartments === null || $selectedDepartments === '') {
                $selectedDepartments = [];
            } else {
                $selectedDepartments = array($selectedDepartments);
            }
        }

        $normalizedDepartments = array();
        foreach ($selectedDepartments as $dep) {
            if ($dep === '' || $dep === null) {
                continue;
            }
            $normalizedDepartments[] = (int) $dep;
        }
        $selectedDepartments = $normalizedDepartments;

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $baseQuery = DB::table('bon_details as d')
            ->join('bon_headers as h', 'd.bon_header_id', '=', 'h.id')
            ->leftJoin('items as i', 'd.item_id', '=', 'i.id')
            ->leftJoin('departments as dept', 'h.department_id', '=', 'dept.id')
            ->where('h.status', '=', 'ISSUED');

        if ($from) {
            $baseQuery->where('h.date', '>=', $from);
        }

        if ($to) {
            $baseQuery->where('h.date', '<=', $to);
        }

        if (count($selectedDepartments) > 0) {
            $baseQuery->whereIn('h.department_id', $selectedDepartments);
        }

        // Filter item berdasarkan scope user
        if (is_array($allowedItemIds)) {
            $baseQuery->whereIn('d.item_id', $allowedItemIds);
        }

        if ($itemId) {
            $baseQuery->where('d.item_id', (int) $itemId);
        }

        $queryForTotal = clone $baseQuery;
        $totalQty      = (int) $queryForTotal->sum('d.issued_quantity');

        $queryForRows = clone $baseQuery;
        $rows = $queryForRows
            ->select(
                'd.id as detail_id',
                'h.date',
                'h.bon_number',
                'h.division_name',
                'i.code as item_code',
                'i.name as item_name',
                'i.unit as item_unit',
                'dept.name as department_name',
                'd.quantity',
                'd.approved_quantity',
                'd.issued_quantity'
            )
            ->orderBy('h.date', 'desc')
            ->orderBy('h.id', 'desc')
            ->orderBy('d.id', 'asc')
            ->paginate($perPage);

        $departments = $this->getActiveRootDepartments();

        // Dropdown barang juga harus ke-filter
        $itemsQuery = Item::orderBy('name', 'asc');
        if (is_array($allowedItemIds)) {
            $itemsQuery->whereIn('id', $allowedItemIds);
        }
        $items = $itemsQuery->get();

        return view('bons.report_per_item', [
            'rows'                => $rows,
            'from'                => $from,
            'to'                  => $to,
            'selectedDepartments' => $selectedDepartments,
            'itemId'              => $itemId,
            'perPage'             => $perPage,
            'departments'         => $departments,
            'items'               => $items,
            'totalQty'            => $totalQty,
        ]);
    }


    // =====================================================================
    // INDEX BON
    // =====================================================================
    public function index(Request $request)
    {
        $perPage = (int) $request->get('perPage', 25);
        if ($perPage <= 0) {
            $perPage = 25;
        }

        $q          = trim($request->get('q', ''));
        
        // --- UPDATE: DEFAULT DATE LOGIC (1st Month to Today) ---
        $from       = $request->has('from') ? $request->get('from') : date('Y-m-01');
        $to         = $request->has('to') ? $request->get('to') : date('Y-m-d');
        
        $department = $request->get('department');
        $status     = $request->get('status');

        // Ambil scope item untuk user saat ini
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $query = BonHeader::with('department');

        // Filter BON berdasarkan buku (inventory_scope)
        if (is_array($allowedItemIds)) {
            $query->whereHas('details', function ($q2) use ($allowedItemIds) {
                $q2->whereIn('item_id', $allowedItemIds);
            });
        }

        // Filter pencarian teks
        if ($q !== '') {
            $like = '%' . $q . '%';
            $query->where(function ($sub) use ($like) {
                $sub->where('bon_number', 'ilike', $like)
                    ->orWhere('notes', 'ilike', $like);
            });
        }

        // Filter tanggal
        if (!empty($from)) {
            $query->where('date', '>=', $from);
        }
        if (!empty($to)) {
            $query->where('date', '<=', $to);
        }

        // Filter departemen
        if (!empty($department)) {
            $query->where('department_id', (int) $department);
        }

        // Filter status
        if (!empty($status)) {
            $query->where('status', $status);
        }

        // Urutan tampilan
        $query->orderBy('date', 'asc')
              ->orderBy('id', 'desc');

        $bons = $query->paginate($perPage)->appends($request->except('page'));

        $departments = $this->getActiveRootDepartments();

        return view('bons.index', [
            'bons'        => $bons,
            'departments' => $departments,
            'q'           => $q,
            'from'        => $from,
            'to'          => $to,
            'department'  => $department,
            'status'      => $status,
            'perPage'     => $perPage,
        ]);
    }

    // =====================================================================
    // CREATE
    // =====================================================================
    public function create()
    {
        $departments = $this->getActiveRootDepartments();
        
        // Division Map kita kosongkan, karena sekarang via AJAX dari DB
        $divisionMap = []; 

        return view('bons.create', [
            'departments' => $departments,
            'divisionMap' => $divisionMap,
        ]);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'date'          => 'required|date',
            'department_id' => 'required|exists:departments,id',
            'division_name' => 'nullable|string|max:100',
        ]);

        $items = (array) $request->get('items', []);
        if (count($items) === 0) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Minimal 1 item harus diisi.');
        }

        DB::beginTransaction();

        try {
            $bon = new BonHeader();
            $bon->date          = $request->get('date');
            $bon->department_id = (int) $request->get('department_id');
            $bon->notes         = $request->get('notes');
            $bon->status        = 'PENDING';

            if (\Schema::hasColumn('bon_headers', 'division_name')) {
                $bon->division_name = $request->get('division_name');
            }

            $bonNumber = trim($request->get('bon_number'));
            if ($bonNumber === '') {
                $bon->bon_number = $this->generateBonNumber(Carbon::parse($bon->date));
            } else {
                $bon->bon_number = $bonNumber;
            }

            $bon->save();

            foreach ($items as $row) {
                if (!isset($row['item_id'])) {
                    continue;
                }

                $itemId = (int) $row['item_id'];
                $qty    = isset($row['quantity']) ? (int) $row['quantity'] : 0;

                if ($qty <= 0) {
                    continue;
                }

                $detail                    = new BonDetail();
                $detail->bon_header_id     = $bon->id;
                $detail->item_id           = $itemId;
                $detail->quantity          = $qty;
                $detail->approved_quantity = 0;
                $detail->issued_quantity   = 0;
                $detail->save();
            }

            DB::commit();

            return redirect()->route('bons.show', $bon->id)
                ->with('success', 'BON berhasil dibuat dan masih berstatus PENDING.');
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()
                ->withInput()
                ->with('error', 'Gagal menyimpan BON: ' . $e->getMessage());
        }
    }

    // =====================================================================
    // SHOW
    // =====================================================================
    public function show($id)
    {
        $bon = BonHeader::with('details.item', 'department')->findOrFail($id);

        // Filter detail BON berdasarkan buku (inventory_scope) user
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();
        if (is_array($allowedItemIds)) {
            $filteredDetails = $bon->details->filter(function ($detail) use ($allowedItemIds) {
                return in_array($detail->item_id, $allowedItemIds);
            })->values();

            $bon->setRelation('details', $filteredDetails);
        }

        $quotaInfo = [];
        $deptId    = $bon->department_id;

        if ($deptId) {
            foreach ($bon->details as $detail) {
                if ($detail->item_id) {
                    $quotaInfo[$detail->id] = $this->getDeptQuotaInfo(
                        $deptId,
                        $detail->item_id,
                        $bon->id
                    );
                }
            }
        }

        $totals = [
            'requested' => 0,
            'approved'  => 0,
            'issued'    => 0,
        ];

        foreach ($bon->details as $d) {
            $totals['requested'] += (int) $d->quantity;
            $totals['approved']  += (int) $d->approved_quantity;
            $totals['issued']    += (int) $d->issued_quantity;
        }

        return view('bons.show', [
            'bon'       => $bon,
            'quotaInfo' => $quotaInfo,
            'totals'    => $totals,
        ]);
    }

    // =====================================================================
    // EDIT
    // =====================================================================
    public function edit($id)
    {
        $bon = BonHeader::with('details.item')->findOrFail($id);

        if ($bon->status !== 'PENDING') {
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Hanya BON PENDING yang dapat diedit.');
        }

        $departments = $this->getActiveRootDepartments();
        
        // Division Map dikosongkan, karena sekarang AJAX
        $divisionMap = [];

        return view('bons.edit', [
            'bon'         => $bon,
            'departments' => $departments,
            'divisionMap' => $divisionMap,
        ]);
    }

    public function update(Request $request, $id)
    {
        $bon = BonHeader::with('details')->findOrFail($id);

        if ($bon->status !== 'PENDING') {
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Hanya BON PENDING yang dapat diupdate.');
        }

        $this->validate($request, [
            'date'          => 'required|date',
            'department_id' => 'required|exists:departments,id',
            'division_name' => 'nullable|string|max:100',
        ]);

        $items = (array) $request->get('items', []);
        if (count($items) === 0) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Minimal 1 item harus diisi.');
        }

        DB::beginTransaction();

        try {
            $bon->date          = $request->get('date');
            $bon->department_id = (int) $request->get('department_id');
            $bon->notes         = $request->get('notes');

            if (\Schema::hasColumn('bon_headers', 'division_name')) {
                $bon->division_name = $request->get('division_name');
            }

            $bonNumber = trim($request->get('bon_number'));
            if ($bonNumber !== '') {
                $bon->bon_number = $bonNumber;
            }

            $bon->save();

            foreach ($bon->details as $d) {
                $d->delete();
            }

            foreach ($items as $row) {
                if (!isset($row['item_id'])) {
                    continue;
                }

                $itemId = (int) $row['item_id'];
                $qty    = isset($row['quantity']) ? (int) $row['quantity'] : 0;

                if ($qty <= 0) {
                    continue;
                }

                $detail                    = new BonDetail();
                $detail->bon_header_id     = $bon->id;
                $detail->item_id           = $itemId;
                $detail->quantity          = $qty;
                $detail->approved_quantity = 0;
                $detail->issued_quantity   = 0;
                $detail->save();
            }

            DB::commit();

            return redirect()->route('bons.show', $bon->id)
                ->with('success', 'BON berhasil diupdate.');
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()
                ->withInput()
                ->with('error', 'Gagal mengupdate BON: ' . $e->getMessage());
        }
    }

    // =====================================================================
    // DESTROY
    // =====================================================================
    public function destroy($id)
    {
        $bon = BonHeader::with('details')->findOrFail($id);

        $reqNo = $this->extractRequestNumberFromBonNotes($bon->notes);
        $wasIssued = ($bon->status === 'ISSUED');

        DB::beginTransaction();
        try {
            // Jika status ISSUED, kembalikan stok
            if ($bon->status === 'ISSUED') {
                foreach ($bon->details as $d) {
                    InventoryHelper::deleteMovement('BON', $bon->id, $d->item_id);
                }
            }

            // Hapus details fisik
            foreach ($bon->details as $d) {
                $d->delete();
            }

            // Hapus header
            $bon->delete();

            // Re-sync request setelah BON hilang (khususnya kalau BON ini pernah APPROVED/ISSUED)
            if ($reqNo) {
                $this->syncRequestProcessedQtyByRequestNumber($reqNo);
            }

            DB::commit();

            return redirect()->route('bons.index')
                ->with('success', 'BON berhasil dihapus' . ($wasIssued ? ' dan stok telah dikembalikan.' : '.'));
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->route('bons.index')
                ->with('error', 'Gagal menghapus BON: ' . $e->getMessage());
        }
    }


    // =====================================================================
    // ROLLBACK (Batalkan Issue)
    // =====================================================================
    public function rollback(Request $request, $id)
    {
        // 1. Cari BON beserta detailnya
        $bon = BonHeader::with('details.item')->findOrFail($id);

        // 2. Cek apakah statusnya beneran ISSUED? Kalau bukan, tolak.
        if ($bon->status !== 'ISSUED') {
            return redirect()->back()->with('error', 'Hanya BON dengan status ISSUED yang bisa dibatalkan.');
        }

        DB::beginTransaction();
        try {
            // 3. Loop setiap item di BON untuk balikin stok
            foreach ($bon->details as $d) {
                // Gunakan Helper InventoryHelper::deleteMovement untuk mengembalikan stok
                // Stok fisik di gudang bertambah kembali
                InventoryHelper::deleteMovement('BON', $bon->id, $d->item_id);

                // Reset jumlah issued di detail jadi 0
                // Approved quantity dibiarkan tetap ada sebagai draft terakhir
                $d->issued_quantity = 0;
                $d->save();
            }

            // 4. Ubah status header jadi PENDING (Biar bisa diedit lagi)
            $bon->status = 'PENDING'; 
            $bon->save();

            DB::commit();

            return redirect()->route('bons.show', $bon->id)
                ->with('success', 'Status dikembalikan ke PENDING. Stok telah dikembalikan dan BON dapat diedit kembali.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Gagal melakukan rollback: ' . $e->getMessage());
        }
    }

    // =====================================================================
    // APPROVE
    // =====================================================================
    public function approve(Request $request, $id)
    {
        $bon = BonHeader::with('details.item', 'department')->findOrFail($id);

        // Terapkan scope filter agar konsisten dengan show()
        $bon = $this->filterBonDetailsByScope($bon);

        if ($bon->status !== 'PENDING') {
            return redirect()->back()
                ->with('error', 'Hanya BON dengan status PENDING yang bisa di-approve.');
        }

        if ($bon->details->count() < 1) {
            return redirect()->back()
                ->with('error', 'Akses Ditolak. Tidak ada item dalam BON ini yang masuk scope Anda.');
        }

        $rows          = $request->input('details', []);
        $overrideQuota = (bool) $request->input('override_quota', false);
        $errors        = [];
        $deptId        = $bon->department_id;
        $deptName      = $bon->department ? $bon->department->name : '-';
        $overQuotaRows = [];

        // 1) VALIDASI (quota + stok) berdasarkan nilai input approved
        foreach ($bon->details as $d) {
            $appr = isset($rows[$d->id]['approved_quantity'])
                ? (int) $rows[$d->id]['approved_quantity']
                : (int) $d->quantity;

            if ($appr < 0) $appr = 0;
            if ($appr > (int) $d->quantity) $appr = (int) $d->quantity;

            $item = $d->item;
            $code = $item ? $item->code : ('Item #' . $d->item_id);

            // cek jatah departemen
            if ($deptId && $d->item_id) {
                $info = $this->getDeptQuotaInfo($deptId, $d->item_id, $bon->id);

                if ($info['total'] > 0 && $appr > (int) $info['remaining']) {
                    $overQuotaRows[] = [
                        'code'      => $code,
                        'remaining' => (int) $info['remaining'],
                        'approved'  => $appr,
                    ];

                    if (!$overrideQuota) {
                        $errors[] =
                            'Sisa jatah departemen ' . $deptName .
                            ' untuk item ' . $code .
                            ' hanya ' . (int) $info['remaining'] .
                            ' tetapi disetujui ' . $appr . '.';
                    }
                }
            }

            // cek stok berdasarkan APPROVED (bukan request)
            if ($item && $appr > (int) $item->current_stock) {
                $errors[] =
                    'Saldo tidak mencukupi untuk item ' . $code .
                    '. Saldo saat ini: ' . (int) $item->current_stock .
                    ', jumlah yang akan disetujui: ' . $appr . '.';
            }
        }

        if (!empty($errors)) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode(' ', $errors));
        }

        DB::beginTransaction();
        try {
            // 2) SIMPAN approved_quantity
            foreach ($bon->details as $d) {
                $appr = isset($rows[$d->id]['approved_quantity'])
                    ? (int) $rows[$d->id]['approved_quantity']
                    : (int) $d->quantity;

                if ($appr < 0) $appr = 0;
                if ($appr > (int) $d->quantity) $appr = (int) $d->quantity;

                $d->approved_quantity = $appr;
                $d->save();
            }

            // 3) status BON -> APPROVED
            $bon->status = 'APPROVED';
            $bon->save();

            // 4) Opsi 2: processed_qty Request baru di-update DI SINI (final)
            $reqNo = $this->extractRequestNumberFromBonNotes($bon->notes);
            if ($reqNo) {
                $this->syncRequestProcessedQtyByRequestNumber($reqNo);
            }

            DB::commit();

            $successMsg = 'BON berhasil di-approve.';
            if (!empty($overQuotaRows) && $overrideQuota) {
                $successMsg =
                    'BON berhasil di-approve sebagai permintaan urgent. ' .
                    'Beberapa baris melebihi jatah dan akan tercatat sebagai penggunaan di luar jatah.';
            }

            return redirect()
                ->route('bons.show', $bon->id)
                ->with('success', $successMsg);

        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()
                ->withInput()
                ->with('error', 'Gagal approve BON: ' . $e->getMessage());
        }
    }

    public function issue(Request $request, $id)
    {
        $bon = BonHeader::with('details.item')->findOrFail($id);

        // Terapkan scope filter agar konsisten dengan show()
        $bon = $this->filterBonDetailsByScope($bon);

        if ($bon->status !== 'APPROVED') {
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Hanya BON berstatus APPROVED yang dapat di-issue.');
        }

        if ($bon->details->count() < 1) {
            return redirect()->back()
                ->with('error', 'Akses Ditolak. Tidak ada item dalam BON ini yang masuk scope Anda.');
        }

        $rows = (array) $request->get('details', []);

        DB::beginTransaction();
        try {
            foreach ($bon->details as $d) {
                $item = $d->item;
                if (!$item) {
                    DB::rollBack();
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Item pada BON tidak ditemukan di master.');
                }

                $issueQty = isset($rows[$d->id]['issued_quantity'])
                    ? (int) $rows[$d->id]['issued_quantity']
                    : (int) $d->approved_quantity;

                if ($issueQty < 0) $issueQty = 0;
                if ($issueQty > (int) $d->approved_quantity) $issueQty = (int) $d->approved_quantity;

                if ($issueQty > (int) $item->current_stock) {
                    DB::rollBack();
                    return redirect()->back()
                        ->withInput()
                        ->with('error', 'Saldo tidak mencukupi untuk item ' . $item->code .
                            '. Saldo: ' . (int) $item->current_stock . ', diminta issue: ' . $issueQty);
                }

                InventoryHelper::recordMovement(
                    $d->item_id,
                    $bon->date,
                    'BON',
                    $bon->id,
                    $bon->bon_number,
                    -1 * $issueQty
                );

                $d->issued_quantity = $issueQty;
                $d->save();
            }

            $bon->status = 'ISSUED';
            $bon->save();

            DB::commit();

            return redirect()->route('bons.show', $bon->id)
                ->with('success', 'BON berhasil di-issue dan stok sudah terpotong.');
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()
                ->withInput()
                ->with('error', 'Gagal melakukan ISSUE: ' . $e->getMessage());
        }
    }


    public function reject(Request $request, $id)
    {
        $bon = BonHeader::findOrFail($id);

        if ($bon->status !== 'PENDING') {
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Hanya BON PENDING yang dapat di-reject.');
        }

        $bon->status = 'REJECTED';
        $bon->save();

        return redirect()->route('bons.show', $bon->id)
            ->with('success', 'BON telah direject.');
    }

    public function cancel(Request $request, $id)
    {
        $bon = BonHeader::findOrFail($id);

        if (!in_array($bon->status, ['APPROVED'])) {
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Hanya BON APPROVED yang dapat dicancel.');
        }

        $reqNo = $this->extractRequestNumberFromBonNotes($bon->notes);

        DB::beginTransaction();
        try {
            $bon->status = 'CANCELLED';
            $bon->save();

            // Re-sync request (karena approved qty dari BON ini harus dianggap hilang)
            if ($reqNo) {
                $this->syncRequestProcessedQtyByRequestNumber($reqNo);
            }

            DB::commit();

            return redirect()->route('bons.show', $bon->id)
                ->with('success', 'BON telah dicancel.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('bons.show', $bon->id)
                ->with('error', 'Gagal cancel BON: ' . $e->getMessage());
        }
    }


    // =====================================================================
    // LOOKUP ITEM
    // =====================================================================
    public function lookupItems(Request $request)
    {
        $q = trim($request->get('q', ''));

        if ($q === '') {
            return response()->json([]);
        }

        $like = '%' . $q . '%';

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $items = Item::where(function ($qq) use ($like) {
                $qq->where('code', 'ILIKE', $like)
                   ->orWhere('name', 'ILIKE', $like);
            });

        if (is_array($allowedItemIds)) {
            $items->whereIn('id', $allowedItemIds);
        }

        $items = $items
            ->orderBy('code', 'asc')
            ->limit(20)
            ->get();

        $out = [];
        foreach ($items as $it) {
            $out[] = [
                'id'         => $it->id,
                'code'       => $it->code,
                'name'       => $it->name,
                'unit'       => $it->unit,
                'buffer_min' => (int) $it->buffer_min,
                'text'       => $it->code . ' - ' . $it->name,
            ];
        }

        return response()->json($out);
    }

    public function resolveItems(Request $request)
    {
        $ids = (array) $request->get('ids', []);

        if (count($ids) === 0) {
            return response()->json([]);
        }

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $items = Item::whereIn('id', $ids);
        if (is_array($allowedItemIds)) {
            $items->whereIn('id', $allowedItemIds);
        }

        $items = $items->get();

        $out = [];
        foreach ($items as $it) {
            $out[] = [
                'id'   => $it->id,
                'code' => $it->code,
                'name' => $it->name,
                'unit' => $it->unit,
                'text' => $it->code . ' - ' . $it->name,
            ];
        }

        return response()->json($out);
    }

    /**
     * Ambil request_number dari notes BON.
     * Format notes yang dipakai di RequestController: "From Req: REQ/202512/0005"
     */
    protected function extractRequestNumberFromBonNotes($notes)
    {
        if (!$notes) return null;

        $matches = array();
        if (preg_match('/From\s+Req:\s*([A-Za-z0-9\/\-_]+)/i', $notes, $matches)) {
            return isset($matches[1]) ? trim($matches[1]) : null;
        }
        return null;
    }

    /**
     * SINKRONISASI processed_qty REQUEST berdasarkan SUM approved_quantity dari BON yang APPROVED/ISSUED
     * Ini bikin Request selalu akurat walaupun:
     * - approve parsial (10 diminta, 8 di-approve)
     * - BON di-cancel / dihapus setelah approve (rollback otomatis via re-sync)
     */
    protected function syncRequestProcessedQtyByRequestNumber($requestNumber)
    {
        if (!$requestNumber) return;

        $hdr = DB::table('request_headers')->where('request_number', $requestNumber)->first();
        if (!$hdr) return;

        // Ambil semua detail request
        $reqDetails = DB::table('request_details')
            ->where('request_header_id', (int) $hdr->id)
            ->get();

        // Pre-aggregate: sum approved_quantity per item_id dari BON terkait request ini (status APPROVED/ISSUED)
        $rows = DB::table('bon_details as bd')
            ->join('bon_headers as bh', 'bd.bon_header_id', '=', 'bh.id')
            ->whereIn('bh.status', array('APPROVED', 'ISSUED'))
            ->where('bh.notes', 'ILIKE', '%From Req: ' . $requestNumber . '%')
            ->groupBy('bd.item_id')
            ->select('bd.item_id', DB::raw('COALESCE(SUM(bd.approved_quantity),0) as total_approved'))
            ->get();

        $mapApproved = array();
        foreach ($rows as $r) {
            $mapApproved[(int) $r->item_id] = (int) $r->total_approved;
        }

        // Update processed_qty per request_detail
        $allDone = true;
        $anyProcessed = false;

        foreach ($reqDetails as $d) {
            $itemId = (int) $d->item_id;
            $need   = (int) $d->quantity;

            $proc = isset($mapApproved[$itemId]) ? (int) $mapApproved[$itemId] : 0;

            // Guard: jangan lebih dari request qty
            if ($proc > $need) $proc = $need;
            if ($proc < 0) $proc = 0;

            DB::table('request_details')
                ->where('id', (int) $d->id)
                ->update(array(
                    'processed_qty' => $proc,
                    'updated_at'    => date('Y-m-d H:i:s'),
                ));

            if ($proc > 0) $anyProcessed = true;
            if ($proc < $need) $allDone = false;
        }

        // Update status header request
        $newStatus = 'APPROVED';
        if ($allDone) {
            $newStatus = 'CLOSED';
        } elseif ($anyProcessed) {
            $newStatus = 'PARTIAL';
        } else {
            // belum ada approved sama sekali -> tetap APPROVED
            $newStatus = 'APPROVED';
        }

        DB::table('request_headers')
            ->where('id', (int) $hdr->id)
            ->update(array(
                'status'     => $newStatus,
                'updated_at' => date('Y-m-d H:i:s'),
            ));
    }



    protected function generateBonNumber(Carbon $date)
    {
        $prefix = 'BON/' . $date->format('Ym') . '/';

        $last = BonHeader::where('bon_number', 'LIKE', $prefix . '%')
            ->orderBy('bon_number', 'desc')
            ->first();

        $nextNumber = 1;
        if ($last) {
            $lastNumber = (int) substr($last->bon_number, strlen($prefix));
            $nextNumber = $lastNumber + 1;
        }

        return $prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
    }

    protected function getAllowedItemIdsForCurrentUser()
    {
        $user = \Auth::user();
        if (!$user) {
            return null;
        }

        if (!method_exists($user, 'categoryCodesForScope')) {
            return null;
        }

        $codes = $user->categoryCodesForScope();

        // ALL → helper mengembalikan null
        if (!is_array($codes) || count($codes) === 0) {
            return null;
        }

        $ids = Item::whereHas('category', function ($q) use ($codes) {
                $q->whereIn('code', $codes);
            })
            ->pluck('id')
            ->all();

        if (count($ids) === 0) {
            // supaya whereIn tidak error, tapi hasil tetap kosong
            return array(-1);
        }

        return $ids;
    }

    protected function isSuperAdmin()
    {
        $u = \Auth::user();
        return ($u && $u->role === 'SUPER_ADMIN');
    }

    /**
     * Filter BON details berdasarkan scope user.
     * - SUPER_ADMIN: semua detail
     * - ADMIN scope: hanya detail item dalam allowedItemIds
     */
    protected function filterBonDetailsByScope(BonHeader $bon)
    {
        if ($this->isSuperAdmin()) {
            return $bon;
        }

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();
        if (is_array($allowedItemIds)) {
            $filtered = $bon->details->filter(function ($detail) use ($allowedItemIds) {
                return in_array((int) $detail->item_id, $allowedItemIds, true);
            })->values();

            $bon->setRelation('details', $filtered);
        }

        return $bon;
    }


}