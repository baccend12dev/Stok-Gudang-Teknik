<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Item;
use App\Category; // <--- Gue tambahin ini biar bisa panggil Kategori

class ItemController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth');

        // === SECURITY LAYER: PERFEKSIONIS ===
        // Memblokir User Dept (USER) agar tidak bisa akses Controller Admin ini.
        // Jika nekat akses URL manual, tendang balik ke halaman Request.
        $this->middleware(function ($request, $next) {
            $user = \Auth::user();
            if ($user && $user->role === 'USER') {
                return redirect()->route('requests.index')->with('error', 'Akses Ditolak! Anda tidak memiliki izin ke halaman tersebut.');
            }
            return $next($request);
        });
    }
    
    public function index(Request $request)
    {
        // ---- Params aman untuk PHP 5.6 (tanpa ??) ----
        $q       = $request->get('q', '');
        $status  = $request->get('status', 'all');
        $unit    = $request->get('unit', 'all');
        $perPage = (int) $request->get('per_page', 25);
        $sort    = $request->get('sort', 'code');
        $dir     = strtolower($request->get('dir', 'asc')) === 'desc' ? 'desc' : 'asc';

        // Dropdown unit (distinct dari items)
        $units = DB::table('items')
            ->whereNotNull('unit')
            ->distinct()
            ->orderBy('unit', 'asc')
            ->pluck('unit')
            ->all();

        // --- Ambil item yang boleh diakses user saat ini ---
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        // ---- Query utama: v (id,code,name) + LEFT JOIN ke items (kolom lain) ----
        $query = DB::table('v_item_saldo as v')
            ->leftJoin('items as i', 'i.id', '=', 'v.id')
            ->select(
                'v.id',
                'v.code',
                'v.name',
                DB::raw("COALESCE(i.unit, '') as unit"),
                DB::raw("COALESCE(i.location, '-') as location"),
                DB::raw("COALESCE(i.current_stock, 0) as current_stock"),
                DB::raw("COALESCE(i.buffer_min, 0) as buffer_min"),
                DB::raw("COALESCE(i.current_status, '') as current_status")
            );

        // Filter berdasarkan item yang diizinkan (scope Bu Ani / Bu Shinta)
        if (is_array($allowedItemIds)) {
            $query->whereIn('v.id', $allowedItemIds);
        }

        // Pencarian kode/nama/lokasi
        if ($q !== '') {
            $like = '%' . $q . '%';
            if (DB::getDriverName() === 'pgsql') {
                $query->where(function ($w) use ($like) {
                    $w->where('v.code', 'ILIKE', $like)
                      ->orWhere('v.name', 'ILIKE', $like)
                      ->orWhere('i.location', 'ILIKE', $like);
                });
            } else {
                $query->where(function ($w) use ($like) {
                    $w->where('v.code', 'like', $like)
                      ->orWhere('v.name', 'like', $like)
                      ->orWhere('i.location', 'like', $like);
                });
            }
        }

        // Filter status (ACTIVE / NONACTIVE)
        if ($status !== 'all' && $status !== '' && $status !== null) {
            $map        = array('AKTIF' => 'ACTIVE', 'NONAKTIF' => 'NONACTIVE');
            $key        = strtoupper($status);
            $normalized = isset($map[$key]) ? $map[$key] : $status;
            $query->where('i.current_status', '=', $normalized);
        }

        // Filter unit
        if ($unit !== 'all' && $unit !== '' && $unit !== null) {
            $query->where('i.unit', $unit);
        }

        // Sorting
        $allowedSort = array('code', 'name', 'unit', 'location', 'current_stock', 'buffer_min', 'current_status');
        if (!in_array($sort, $allowedSort)) {
            $sort = 'code';
        }

        switch ($sort) {
            case 'name':
                $query->orderBy('v.name', $dir);
                break;
            case 'unit':
                $query->orderBy('i.unit', $dir);
                break;
            case 'location':
                $query->orderBy('i.location', $dir);
                break;
            case 'current_stock':
                $query->orderBy('i.current_stock', $dir);
                break;
            case 'buffer_min':
                $query->orderBy('i.buffer_min', $dir);
                break;
            case 'current_status':
                $query->orderBy('i.current_status', $dir)
                      ->orderBy('v.code', 'asc');
                break;
            default:
                $query->orderBy('v.code', $dir);
        }

        $items = $query->paginate($perPage);

        // Tambahkan query string biar pagination tetap bawa filter
        $items->appends(array(
            'q'        => $q,
            'status'   => $status,
            'unit'     => $unit,
            'per_page' => $perPage,
            'sort'     => $sort,
            'dir'      => $dir
        ));

        return view('items.index', array(
            'items'   => $items,
            'q'       => $q,
            'status'  => $status,
            'unit'    => $unit,
            'perPage' => $perPage,
            'sort'    => $sort,
            'dir'     => $dir,
            'units'   => $units
        ));
    }

    public function create()
    {
        // --- LOGIC BARU: Ambil Kategori Sesuai User ---
        $user = auth()->user();
        
        $codes = null;
        if (method_exists($user, 'categoryCodesForScope')) {
            $codes = $user->categoryCodesForScope();
        }

        // Jika user punya scope (Bu Ani/Shinta), ambil kategori yg sesuai aja
        if ($codes && count($codes) > 0) {
            $categories = Category::whereIn('code', $codes)->get();
        } else {
            // Super Admin dapet semua
            $categories = Category::all();
        }

        // Kita juga kirim units untuk datalist
        $units = DB::table('items')
            ->whereNotNull('unit')
            ->distinct()
            ->orderBy('unit', 'asc')
            ->pluck('unit')
            ->all();

        return view('items.create', array(
            'categories' => $categories,
            'units'      => $units
        ));
    }

    public function store(Request $request)
    {
        // Validasi
        $this->validate($request, [
            'code'        => 'required|unique:items,code',
            'name'        => 'required',
            'category_id' => 'required', // <--- WAJIB DIPILIH
        ]);

        $data = array(
            'code'           => $request->get('code'),
            'name'           => $request->get('name'),
            'category_id'    => $request->get('category_id'), // <--- SIMPAN KE DB
            'unit'           => $request->get('unit'),
            'location'       => $request->get('location'),
            'current_stock'  => (int)$request->get('current_stock', 0),
            'buffer_min'     => (int)$request->get('buffer_min', 0),
            'current_status' => $request->get('current_status', 'ACTIVE'),
            'note'           => $request->get('note')
        );
        
        Item::create($data);
        return redirect()->route('items.index')->with('success', 'Item berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $item = Item::findOrFail($id);

        // --- LOGIC BARU: Ambil Kategori Sesuai User (Sama kayak Create) ---
        $user = auth()->user();
        $codes = null;
        if (method_exists($user, 'categoryCodesForScope')) {
            $codes = $user->categoryCodesForScope();
        }

        if ($codes && count($codes) > 0) {
            $categories = Category::whereIn('code', $codes)->get();
        } else {
            $categories = Category::all();
        }

        $units = DB::table('items')
            ->whereNotNull('unit')
            ->distinct()
            ->orderBy('unit', 'asc')
            ->pluck('unit')
            ->all();

        return view('items.edit', array(
            'item'       => $item,
            'categories' => $categories,
            'units'      => $units
        ));
    }

    public function update(Request $request, $id)
    {
        $item = Item::findOrFail($id);
        
        // Update data termasuk category_id
        $item->code           = $request->get('code');
        $item->name           = $request->get('name');
        $item->category_id    = $request->get('category_id'); // <--- UPDATE KATEGORI
        $item->unit           = $request->get('unit');
        $item->location       = $request->get('location');
        $item->current_stock  = (int)$request->get('current_stock', 0);
        $item->buffer_min     = (int)$request->get('buffer_min', 0);
        $item->current_status = $request->get('current_status', 'ACTIVE');
        $item->note           = $request->get('note');
        $item->save();

        return redirect()->route('items.index')->with('success', 'Item berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $item = Item::findOrFail($id);
        $item->delete();
        return redirect()->route('items.index')->with('success', 'Item berhasil dihapus.');
    }

    /**
    * Ambil daftar ID item yang boleh diakses user saat ini
    * berdasarkan inventory_scope.
    */
    protected function getAllowedItemIdsForCurrentUser()
    {
        $user = auth()->user();

        if (!$user || !method_exists($user, 'categoryCodesForScope')) {
            return null;
        }

        $codes = $user->categoryCodesForScope();
        if (!is_array($codes) || count($codes) === 0) {
            // ALL → tidak ada filter kategori
            return null;
        }

        // Ambil semua item.id yang kategori-nya termasuk scope user
        $ids = \App\Item::whereHas('category', function ($q) use ($codes) {
                $q->whereIn('code', $codes);
            })
            ->pluck('id')
            ->all();

        // Kalau belum ada item sama sekali, balikin array dummy
        if (count($ids) === 0) {
            return array(-1); 
        }

        return $ids;
    }
}