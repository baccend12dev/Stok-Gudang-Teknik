<?php

namespace App\Http\Controllers;

use App\RequestHeader;
use App\RequestDetail;
use App\Department;
use App\Item;
use App\BonHeader;
use App\BonDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RequestController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    // ============================================================
    // 1) INDEX
    // ============================================================
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = RequestHeader::with(['department', 'user', 'details'])
            ->orderBy('date', 'desc')
            ->orderBy('id', 'desc');

        if ($user->role === 'USER') {
            $query->where('user_id', $user->id);
        }

        // Laravel 5.4: jangan pakai filled()
        $from   = trim((string) $request->get('from', ''));
        $to     = trim((string) $request->get('to', ''));
        $status = strtoupper(trim((string) $request->get('status', 'ALL')));
        $search = trim((string) $request->get('search', ''));

        if ($from !== '') {
            $query->whereDate('date', '>=', $from);
        }
        if ($to !== '') {
            $query->whereDate('date', '<=', $to);
        }
        if ($status !== '' && $status !== 'ALL') {
            $query->where('status', $status);
        }
        if ($search !== '') {
            $query->where('request_number', 'like', '%' . $search . '%');
        }

        $requests = $query->paginate(20);

        return view('requests.index', [
            'requests' => $requests,
            'user'     => $user,
        ]);
    }

    // ============================================================
    // 2) CREATE
    // ============================================================
    public function create()
    {
        $user = Auth::user();

        $department = null;
        if (!empty($user->department_id)) {
            $department = Department::find($user->department_id);
        }

        $items = Item::with('category')
            ->where('current_status', 'ACTIVE')
            ->orderBy('code', 'asc')
            ->get();

        return view('requests.create', [
            'items'      => $items,
            'department' => $department,
        ]);
    }

    // ============================================================
    // 3) STORE
    // ============================================================
    public function store(Request $request)
    {
        $user = Auth::user();

        if (empty($user->department_id)) {
            return back()->withInput()->with('error', 'User belum memiliki Department. Isi department_id di tabel users.');
        }

        $this->validate($request, [
            'notes'            => 'nullable|string|max:255',
            'items'            => 'required|array|min:1',
            'items.*.item_id'  => 'required|exists:items,id',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.remarks'  => 'nullable|string|max:255',
        ]);

        DB::beginTransaction();
        try {
            $hdr = new RequestHeader();
            $hdr->request_number = $this->generateRequestNumber();
            $hdr->date           = Carbon::now()->format('Y-m-d');
            $hdr->department_id  = $user->department_id;
            $hdr->user_id        = $user->id;
            $hdr->notes          = $request->get('notes');
            $hdr->status         = 'OPEN';
            $hdr->bon_header_id  = null;
            $hdr->save();

            foreach ($request->get('items', []) as $row) {
                $itemId = isset($row['item_id']) ? $row['item_id'] : null;
                if (empty($itemId)) continue;

                $dtl = new RequestDetail();
                $dtl->request_header_id = $hdr->id;
                $dtl->item_id           = (int) $itemId;
                $dtl->quantity          = (int) $row['quantity'];
                $dtl->remarks           = isset($row['remarks']) ? $row['remarks'] : null;

                // Opsi 2: processed_qty adalah FINAL (diisi ketika BON di-approve)
                $dtl->processed_qty     = 0;
                $dtl->save();
            }

            $countDetail = RequestDetail::where('request_header_id', $hdr->id)->count();
            if ($countDetail < 1) {
                DB::rollBack();
                return back()->withInput()->with('error', 'Minimal harus ada 1 item yang dipilih.');
            }

            DB::commit();
            return redirect()->route('requests.index')
                ->with('success', 'Request berhasil dibuat: ' . $hdr->request_number);

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    // ============================================================
    // 4) SHOW
    // ============================================================
    public function show($id)
    {
        $hdr = RequestHeader::with(['details.item.category', 'department', 'user'])->findOrFail($id);

        $user = Auth::user();
        if ($user->role === 'USER' && $hdr->user_id !== $user->id) {
            abort(403, 'Anda tidak punya akses ke request ini.');
        }

        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser(); // array atau null
        $reservedMap    = $this->getReservedPendingQtyMap($hdr->request_number); // item_id => qty reserved di BON PENDING

        $mineTotalQty  = 0; $mineDoneQty  = 0; $mineReservedQty = 0;
        $otherTotalQty = 0; $otherDoneQty = 0; $otherReservedQty = 0;

        $canProcessAny = false;

        if ($user->role !== 'USER' && ($hdr->status === 'APPROVED' || $hdr->status === 'PARTIAL')) {
            foreach ($hdr->details as $d) {
                $qty      = (int) $d->quantity;
                $done     = (int) $d->processed_qty; // FINAL: berasal dari BON APPROVED/ISSUED
                $reserved = isset($reservedMap[(int)$d->item_id]) ? (int)$reservedMap[(int)$d->item_id] : 0;

                // Sisa untuk dibuat BON draft (PENDING)
                $remForDraft = $qty - $done - $reserved;

                $isMine = true;
                if (is_array($allowedItemIds)) {
                    // penting: parameter 2 HARUS array (kita sudah guard)
                    $isMine = in_array((int) $d->item_id, $allowedItemIds, true);
                }

                if ($isMine) {
                    $mineTotalQty     += $qty;
                    $mineDoneQty      += $done;
                    $mineReservedQty  += $reserved;
                    if ($remForDraft > 0) $canProcessAny = true;
                } else {
                    $otherTotalQty     += $qty;
                    $otherDoneQty      += $done;
                    $otherReservedQty  += $reserved;
                }
            }
        }

        // “Remain” yang tampil untuk admin sebaiknya = sisa untuk dibuat BON draft
        $mineRemain  = (int) $mineTotalQty - (int) $mineDoneQty - (int) $mineReservedQty;
        $otherRemain = (int) $otherTotalQty - (int) $otherDoneQty - (int) $otherReservedQty;

        if ($mineRemain < 0) $mineRemain = 0;
        if ($otherRemain < 0) $otherRemain = 0;

        // Ambil daftar BON terkait request (semua status) agar mudah audit
        $relatedBons = BonHeader::where('notes', 'ILIKE', '%From Req: ' . $hdr->request_number . '%')
            ->orderBy('date', 'desc')
            ->orderBy('id', 'desc')
            ->get();

        return view('requests.show', [
            'hdr'             => $hdr,
            'user'            => $user,
            'allowedItemIds'  => $allowedItemIds,
            'reservedMap'     => $reservedMap,
            'mineTotalQty'    => $mineTotalQty,
            'mineDoneQty'     => $mineDoneQty,
            'mineReservedQty' => $mineReservedQty,
            'mineRemain'      => $mineRemain,
            'otherTotalQty'   => $otherTotalQty,
            'otherDoneQty'    => $otherDoneQty,
            'otherReservedQty'=> $otherReservedQty,
            'otherRemain'     => $otherRemain,
            'canProcessAny'   => $canProcessAny,
            'relatedBons'     => $relatedBons,
        ]);
    }

    // ============================================================
    // 5) APPROVE / REJECT / CANCEL
    // ============================================================
    public function approve($id)
    {
        $hdr = RequestHeader::findOrFail($id);

        if (!$this->isAdmin(Auth::user())) {
            abort(403, 'Hanya admin yang boleh approve.');
        }

        if ($hdr->status !== 'OPEN') {
            return back()->with('error', 'Request tidak bisa di-approve karena status bukan OPEN.');
        }

        $hdr->status = 'APPROVED';
        $hdr->save();

        return back()->with('success', 'Request berhasil di-approve.');
    }

    public function reject($id)
    {
        $hdr = RequestHeader::findOrFail($id);

        if (!$this->isAdmin(Auth::user())) {
            abort(403, 'Hanya admin yang boleh reject.');
        }

        if ($hdr->status !== 'OPEN') {
            return back()->with('error', 'Request tidak bisa di-reject karena status bukan OPEN.');
        }

        $hdr->status = 'REJECTED';
        $hdr->save();

        return back()->with('success', 'Request berhasil di-reject.');
    }

    public function cancel($id)
    {
        $hdr = RequestHeader::findOrFail($id);
        $user = Auth::user();

        if ($user->role === 'USER' && $hdr->user_id !== $user->id) {
            abort(403, 'Anda tidak punya akses.');
        }

        if (!in_array($hdr->status, ['OPEN'], true)) {
            return back()->with('error', 'Request hanya bisa dibatalkan saat status OPEN.');
        }

        $hdr->status = 'CANCELLED';
        $hdr->save();

        return back()->with('success', 'Request berhasil dibatalkan.');
    }

    // ============================================================
    // 6) CREATE BON FROM REQUEST
    // - ADMIN scope: buat 1 BON untuk sisa scope dia (menghitung reserved PENDING)
    // - SUPER_ADMIN: auto-split (GENERAL/APPAREL/OTHER) untuk sisa yang belum reserved
    //
    // IMPORTANT (Opsi 2):
    // - processed_qty TIDAK diubah di sini.
    // - processed_qty akan di-sync saat BON di-approve (BonController->approve).
    // ============================================================
    public function createBonFromRequest(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $hdr  = RequestHeader::with(['details.item.category'])->findOrFail($id);
            $user = Auth::user();

            if (!$this->isAdmin($user)) {
                abort(403, 'Hanya admin yang boleh membuat BON dari Request.');
            }

            if ($hdr->status !== 'APPROVED' && $hdr->status !== 'PARTIAL') {
                return back()->with('error', 'Request belum disetujui atau sudah selesai.');
            }

            $allowedItemIds = $this->getAllowedItemIdsForCurrentUser(); // array atau null
            $reservedMap    = $this->getReservedPendingQtyMap($hdr->request_number);

            // NON super admin wajib punya scope array
            if ($user->role !== 'SUPER_ADMIN' && !is_array($allowedItemIds)) {
                return back()->with('error', 'Scope kategori Anda belum diset. Hubungi SUPER_ADMIN.');
            }

            // ========================================================
            // CASE A: SUPER_ADMIN => AUTO SPLIT
            // ========================================================
            if ($user->role === 'SUPER_ADMIN') {

                $GENERAL_CODES = ['ATK','SBN','AKB','UMM'];
                $APPAREL_CODES = ['AK','PK'];

                $groups = [
                    'GENERAL' => [],
                    'APPAREL' => [],
                    'OTHER'   => [],
                ];

                foreach ($hdr->details as $d) {
                    $qty      = (int) $d->quantity;
                    $done     = (int) $d->processed_qty;
                    $reserved = isset($reservedMap[(int)$d->item_id]) ? (int)$reservedMap[(int)$d->item_id] : 0;

                    $remainingForDraft = $qty - $done - $reserved;
                    if ($remainingForDraft <= 0) continue;

                    $catCode = '';
                    if ($d->item && $d->item->category && $d->item->category->code) {
                        $catCode = strtoupper(trim($d->item->category->code));
                    }

                    if ($catCode !== '' && in_array($catCode, $GENERAL_CODES, true)) {
                        $groups['GENERAL'][] = ['detail_obj' => $d, 'qty_to_process' => $remainingForDraft];
                    } elseif ($catCode !== '' && in_array($catCode, $APPAREL_CODES, true)) {
                        $groups['APPAREL'][] = ['detail_obj' => $d, 'qty_to_process' => $remainingForDraft];
                    } else {
                        $groups['OTHER'][] = ['detail_obj' => $d, 'qty_to_process' => $remainingForDraft];
                    }
                }

                $created = [];
                foreach ($groups as $key => $rows) {
                    if (count($rows) < 1) continue;

                    $label = ($key === 'GENERAL')
                        ? 'From Req: ' . $hdr->request_number . ' | Scope GENERAL (Bu Ani)'
                        : (($key === 'APPAREL')
                            ? 'From Req: ' . $hdr->request_number . ' | Scope APPAREL (Bu Shinta)'
                            : 'From Req: ' . $hdr->request_number . ' | Scope OTHER (Unmapped)');

                    $bon = $this->createBonHeaderAndDetails($hdr, $rows, $label);

                    $created[] = [
                        'id'     => $bon->id,
                        'number' => $bon->bon_number,
                        'label'  => $label,
                    ];
                }

                if (count($created) < 1) {
                    return back()->with('error', 'Tidak ada item tersisa yang bisa diproses (sudah masuk draft / sudah final).');
                }

                DB::commit();

                return redirect()
                    ->route('requests.show', $hdr->id)
                    ->with('success', 'BON berhasil dibuat (Auto Split).')
                    ->with('created_bons', $created);
            }

            // ========================================================
            // CASE B: ADMIN scope => 1 BON untuk sisa scope dia
            // ========================================================
            $detailsToProcess = [];
            foreach ($hdr->details as $d) {
                $qty      = (int) $d->quantity;
                $done     = (int) $d->processed_qty;
                $reserved = isset($reservedMap[(int)$d->item_id]) ? (int)$reservedMap[(int)$d->item_id] : 0;

                $remainingForDraft = $qty - $done - $reserved;
                if ($remainingForDraft <= 0) continue;

                $isMyScope = true;
                if (is_array($allowedItemIds)) {
                    $isMyScope = in_array((int) $d->item_id, $allowedItemIds, true);
                }

                if ($isMyScope) {
                    $detailsToProcess[] = [
                        'detail_obj'     => $d,
                        'qty_to_process' => $remainingForDraft,
                    ];
                }
            }

            if (count($detailsToProcess) === 0) {
                return back()->with('error', 'Tidak ada item scope Anda yang perlu diproses (sudah masuk draft / sudah final).');
            }

            $bon = $this->createBonHeaderAndDetails(
                $hdr,
                $detailsToProcess,
                'From Req: ' . $hdr->request_number
            );

            DB::commit();

            return redirect()->route('bons.show', $bon->id)->with('success', 'BON berhasil dibuat (PENDING). Silakan approve untuk final.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal: ' . $e->getMessage());
        }
    }

    /**
     * Buat BON header + details.
     *
     * IMPORTANT (Opsi 2):
     * - processed_qty RequestDetail TIDAK diubah di sini.
     * - processed_qty akan di-sync saat BON APPROVED/ISSUED (di BonController->approve via syncRequestProcessedQtyByRequestNumber).
     *
     * Schema kamu:
     * - bon_details: approved_quantity, issued_quantity
     * - tidak ada kolom remarks di bon_details
     */
    private function createBonHeaderAndDetails(RequestHeader $hdr, array $rows, $notes)
    {
        $bon = new BonHeader();
        $bon->bon_number    = $this->generateBonNumber(Carbon::now());
        $bon->date          = Carbon::now()->format('Y-m-d');
        $bon->department_id = $hdr->department_id;
        $bon->notes         = $notes;
        $bon->status        = 'PENDING';
        $bon->save();

        foreach ($rows as $data) {
            $d   = $data['detail_obj'];
            $qty = (int) $data['qty_to_process'];
            if ($qty <= 0) continue;

            $bd = new BonDetail();
            $bd->bon_header_id     = $bon->id;
            $bd->item_id           = (int) $d->item_id;
            $bd->quantity          = $qty;
            $bd->approved_quantity = 0; // baru diisi saat approve
            $bd->issued_quantity   = 0;
            $bd->save();
        }

        return $bon;
    }

    // ============================================================
    // RESERVED MAP: qty di BON PENDING untuk request ini
    // (mencegah double draft / tombol canProcessAny jadi akurat)
    // ============================================================
    private function getReservedPendingQtyMap($requestNumber)
    {
        $map = [];

        if (!$requestNumber) return $map;

        $rows = DB::table('bon_details as bd')
            ->join('bon_headers as bh', 'bd.bon_header_id', '=', 'bh.id')
            ->where('bh.status', '=', 'PENDING')
            ->where('bh.notes', 'ILIKE', '%From Req: ' . $requestNumber . '%')
            ->groupBy('bd.item_id')
            ->select('bd.item_id', DB::raw('COALESCE(SUM(bd.quantity),0) as total_qty'))
            ->get();

        foreach ($rows as $r) {
            $map[(int)$r->item_id] = (int)$r->total_qty;
        }

        return $map;
    }

    // ============================================================
    // HELPERS
    // ============================================================
    protected function generateBonNumber(Carbon $date)
    {
        $prefix = 'BON/' . $date->format('Ym') . '/';
        $last = BonHeader::where('bon_number', 'LIKE', $prefix . '%')
            ->orderBy('bon_number', 'desc')
            ->first();

        $next = $last ? ((int) substr($last->bon_number, -4)) + 1 : 1;
        return $prefix . str_pad($next, 4, '0', STR_PAD_LEFT);
    }

    protected function generateRequestNumber()
    {
        $date = Carbon::now();
        $prefix = 'REQ/' . $date->format('Ym') . '/';
        $last = RequestHeader::where('request_number', 'LIKE', $prefix . '%')
            ->orderBy('request_number', 'desc')
            ->first();

        $next = $last ? ((int) substr($last->request_number, -4)) + 1 : 1;
        return $prefix . str_pad($next, 4, '0', STR_PAD_LEFT);
    }

    protected function isAdmin($user)
    {
        // Kamu pakai inventory_scope via categoryCodesForScope
        return $user && method_exists($user, 'categoryCodesForScope') && $user->role !== 'USER';
    }

    protected function getAllowedItemIdsForCurrentUser()
    {
        $user = Auth::user();
        if (!$user || !method_exists($user, 'categoryCodesForScope')) return null;

        $codes = $user->categoryCodesForScope();
        if (!is_array($codes) || empty($codes)) return null;

        return Item::whereHas('category', function ($q) use ($codes) {
            $q->whereIn('code', $codes);
        })->pluck('id')->toArray();
    }
}
