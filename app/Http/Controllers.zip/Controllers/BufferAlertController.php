<?php

namespace App\Http\Controllers;

use App\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Excel;

class BufferAlertController extends Controller
{   
    public function __construct()
    {
        $this->middleware('auth');

        // === SECURITY LAYER: PERFEKSIONIS ===
        // Memblokir User Dept (USER) agar tidak bisa akses Controller Admin ini.
        // Jika nekat akses URL manual, tendang balik ke halaman Request.
        $this->middleware(function ($request, $next) {
            $user = \Auth::user();
            if ($user && $user->role === 'USER') {
                return redirect()->route('requests.index')->with('error', 'Akses Ditolak! Anda tidak memiliki izin ke halaman tersebut.');
            }
            return $next($request);
        });
    }
    
    /**
     * Halaman Peringatan Stok & Monitoring (Inventory Command Center).
     * Sekarang sudah otomatis filter sesuai inventory_scope user.
     */
    public function index(Request $request)
    {
        $search   = trim($request->get('search', ''));
        $level    = $request->get('buffer_level', 'all');
        $perPage  = (int) $request->get('per_page', 10);
        if ($perPage < 1) {
            $perPage = 10;
        }

        // Daftar item yang boleh dilihat user (null = bebas semua)
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        // --- 1. HITUNG STATISTIK GLOBAL (KPI CARDS) ---
        $allItemsQuery = Item::select('id', 'current_stock', 'buffer_min')
            ->where('current_status', 'ACTIVE');

        if (!is_null($allowedItemIds)) {
            $allItemsQuery->whereIn('id', $allowedItemIds);
        }

        $allItems = $allItemsQuery->get();

        $stats = [
            'total'    => 0,
            'critical' => 0, // Stok < Buffer (Merah) + stok 0
            'warning'  => 0, // Buffer <= Stok <= Buffer + 5 (Kuning)
            'safe'     => 0  // Stok > Buffer + 5 (Hijau)
        ];

        foreach ($allItems as $item) {
            $stats['total']++;
            $stok = (int) $item->current_stock;
            $buff = (int) $item->buffer_min;

            if ($stok <= 0) {
                $stats['critical']++;
            } elseif ($stok < $buff) {
                $stats['critical']++;
            } elseif ($stok <= ($buff + 5)) {
                $stats['warning']++;
            } else {
                $stats['safe']++;
            }
        }

        // --- 2. QUERY DATA TABEL (FILTERING) ---
        $q = Item::where('current_status', 'ACTIVE');

        if (!is_null($allowedItemIds)) {
            $q->whereIn('id', $allowedItemIds);
        }

        // Filter Pencarian
        if ($search !== '') {
            $q->where(function ($qq) use ($search) {
                $qq->where('code', 'ilike', '%' . $search . '%')
                    ->orWhere('name', 'ilike', '%' . $search . '%');
            });
        }

        // Filter Level (berdasarkan card yang diklik)
        if ($level === 'critical') {
            $q->where(function ($qq) {
                $qq->whereRaw('current_stock <= 0')
                    ->orWhereRaw('current_stock < buffer_min');
            });
        } elseif ($level === 'warning') {
            $q->whereRaw('current_stock > 0')
                ->whereRaw('current_stock >= buffer_min')
                ->whereRaw('current_stock <= (buffer_min + 5)');
        } elseif ($level === 'safe') {
            $q->whereRaw('current_stock > (buffer_min + 5)');
        }
        // 'all' ⇒ tanpa filter level

        // Ambil data + Pagination
        $items = $q->orderBy('current_stock', 'asc')
            ->paginate($perPage)
            ->appends($request->query());

        // --- 3. LOGIC SARAN ORDER (TRANSFORMASI DATA) ---
        $items->getCollection()->transform(function ($item) {
            $target = ($item->buffer_min * 2) < 10 ? 10 : ($item->buffer_min * 2);
            $item->suggested_qty = ($target - $item->current_stock) > 0 ? ($target - $item->current_stock) : 0;

            if ($item->current_stock <= 0) {
                $item->status_label = 'KOSONG';
                $item->status_class = 'badge-danger';
            } elseif ($item->current_stock < $item->buffer_min) {
                $item->status_label = 'KRITIS';
                $item->status_class = 'badge-danger';
            } elseif ($item->current_stock <= ($item->buffer_min + 5)) {
                $item->status_label = 'MENIPIS';
                $item->status_class = 'badge-warning';
            } else {
                $item->status_label = 'AMAN';
                $item->status_class = 'badge-success';
            }
            return $item;
        });

        return view('alerts.index', compact('items', 'search', 'level', 'perPage', 'stats'));
    }

    /**
     * Export Excel – otomatis hanya item yang boleh dilihat user.
     */
    public function exportExcel(Request $request)
    {
        $allowedItemIds = $this->getAllowedItemIdsForCurrentUser();

        $itemsQuery = Item::where('current_status', 'ACTIVE')
            ->whereRaw('current_stock <= (buffer_min + 5)');

        if (!is_null($allowedItemIds)) {
            $itemsQuery->whereIn('id', $allowedItemIds);
        }

        $items = $itemsQuery->orderBy('current_stock', 'asc')->get();

        return Excel::create('Rencana_Pembelian_' . date('d-m-Y'), function ($excel) use ($items) {
            $excel->sheet('Plan', function ($sheet) use ($items) {
                $sheet->row(1, ['KODE', 'NAMA BARANG', 'LOKASI', 'SATUAN', 'STOK SAAT INI', 'BUFFER MIN', 'STATUS', 'SARAN ORDER (QTY)']);
                $sheet->row(1, function ($row) {
                    $row->setBackground('#FFEDB8')->setFontWeight('bold')->setAlignment('center');
                });

                $row = 2;
                foreach ($items as $item) {
                    $target = ($item->buffer_min * 2) < 10 ? 10 : ($item->buffer_min * 2);
                    $saran = ($target - $item->current_stock) > 0 ? ($target - $item->current_stock) : 0;

                    $status = 'MENIPIS';
                    if ($item->current_stock <= 0) {
                        $status = 'KOSONG';
                    } elseif ($item->current_stock < $item->buffer_min) {
                        $status = 'KRITIS';
                    }

                    $sheet->row($row, [
                        $item->code,
                        $item->name,
                        $item->location,
                        $item->unit,
                        (float) $item->current_stock,
                        (float) $item->buffer_min,
                        $status,
                        (float) $saran
                    ]);
                    $row++;
                }
                $sheet->setAutoSize(true);
            });
        })->download('xlsx');
    }

    /**
     * Helper: daftar ID item yang boleh diakses user sesuai inventory_scope.
     * Return:
     *   - null  : tidak ada batasan (ALL)
     *   - array : list id item yg boleh ditampilkan
     */
    protected function getAllowedItemIdsForCurrentUser()
    {
        $user = Auth::user();
        if (!$user) {
            return null;
        }

        $scope = $user->inventory_scope;

        // ALL atau kosong ⇒ bebas semua kategori
        if ($scope === 'ALL' || $scope === null || $scope === '') {
            return null;
        }

        // Ambil kode kategori dari helper di model User
        $categoryCodes = [];
        if (method_exists($user, 'categoryCodesForScope')) {
            $categoryCodes = $user->categoryCodesForScope();
        } else {
            if ($scope === 'GENERAL') {
                $categoryCodes = ['UNCAT', 'ATK', 'SBN', 'AKB', 'UMM'];
            } elseif ($scope === 'APPAREL') {
                $categoryCodes = ['AK', 'PK'];
            }
        }

        if (empty($categoryCodes)) {
            return null;
        }

        return Item::whereHas('category', function ($q) use ($categoryCodes) {
            $q->whereIn('code', $categoryCodes);
        })->pluck('id')->toArray();
    }
}
